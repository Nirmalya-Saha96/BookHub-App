package com.nirmalya.bookhubb.model

data class book (
        val bookId: String,
        val bookName: String,
        val bookAuthor: String,
        val bookPrice: String,
        val bookRating: String,
        val bookImage: String
)